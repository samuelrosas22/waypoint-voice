package com.waypointvoice.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.ArrayList;
import java.util.List;

/**
 * Hosts the Waypoint Voice web app (app/src/main/assets/index.html) and gives it
 * native powers through NativeBridge: background GPS, music controls, ducked voice audio.
 */
public class MainActivity extends Activity {
    static final String START_URL = "https://appassets.androidplatform.net/assets/index.html";
    static final int REQ_PERMS = 1;
    static final int REQ_MIC = 2;

    WebView web;
    NativeBridge bridge;
    boolean usingBundled = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setUserAgentString(s.getUserAgentString() + " WaypointVoice/1.0");

        // Serve the bundled web app from a secure https address so storage, caching and CORS all work.
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        final String remote = BuildConfig.WEB_URL;
        final String remoteHost = remote.isEmpty() ? "" : Uri.parse(remote).getHost();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost();
                if ("appassets.androidplatform.net".equals(host) || (!remoteHost.isEmpty() && remoteHost.equals(host))) return false;
                openExternal(u); // websites, phone numbers etc. open in their own apps
                return true;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, android.webkit.WebResourceError error) {
                // No signal or site unreachable: fall back to the copy built into the app
                if (request.isForMainFrame() && !usingBundled) {
                    usingBundled = true;
                    view.loadUrl(START_URL);
                }
            }

            @Override
            public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse response) {
                if (request.isForMainFrame() && !usingBundled && response.getStatusCode() >= 400) {
                    usingBundled = true;
                    view.loadUrl(START_URL);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient());

        bridge = new NativeBridge(this, web);
        web.addJavascriptInterface(bridge, "Native");
        if (remote.isEmpty()) { usingBundled = true; web.loadUrl(START_URL); }
        else web.loadUrl(remote);

        askPermissions();
    }

    void openExternal(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) { }
    }

    void askPermissions() {
        List<String> need = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION);
            need.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!need.isEmpty()) requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    void askMic() {
        requestPermissions(new String[]{ Manifest.permission.RECORD_AUDIO }, REQ_MIC);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) bridge.onLocationPermissionResult();
        if (requestCode == REQ_MIC) bridge.onMicPermissionResult(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);
    }

    @Override
    protected void onResume() {
        super.onResume();
        bridge.js("window.__nativeResume && window.__nativeResume()");
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else moveTaskToBack(true); // keep running (and navigating) instead of closing
    }

    @Override
    protected void onDestroy() {
        bridge.destroy();
        web.destroy();
        super.onDestroy();
    }
}
